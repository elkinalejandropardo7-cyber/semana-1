from django.apps import AppConfig


class Prueva2Config(AppConfig):
    name = 'prueva2'
