from django.apps import AppConfig


class AppparqueoConfig(AppConfig):
    name = 'appparqueo'
